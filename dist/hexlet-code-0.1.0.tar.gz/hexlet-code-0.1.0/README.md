### Hexlet tests and linter status:
[![Actions Status](https://github.com/hex-learning/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/hex-learning/python-project-49/actions)
<a href="https://codeclimate.com/github/hex-learning/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c0fe1ccae73da372f239/maintainability" /></a>
https://asciinema.org/a/FRVNZQ1gPgtgsoEL4FrAF3MNW - even
https://asciinema.org/a/PIqNPeoKdKNgeaCi8zwoQqyvV - calc
https://asciinema.org/a/MsSwb8kapvuN7DGvAFayaIHMv - gcd

from ..main_logic import welcome_user

welcome_user()